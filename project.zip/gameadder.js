import mongoose from 'mongoose';
import Games from './models/games.js'
import fs from 'fs/promises';

async function deleteGamesWithMissingUrl() {
    // Connect to MongoDB
    const uri = 'mongodb+srv://eclipsesword777:HNcLrnsCMenbCxf6@cluster0.dvhrksp.mongodb.net/GameEcommerce?retryWrites=true&w=majority&appName=Cluster0';
    await mongoose.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true });

    try {
        // Delete all documents where the 'url' field is missing
        const result = await Games.deleteMany({ url: { $exists: false } });
        console.log('Documents deleted:', result.deletedCount);
    } catch (error) {
        console.error('Error deleting documents:', error);
    } finally {
        await mongoose.disconnect();
    }
}


function createUrlFromTitle(title) {
    return title.toLowerCase().replace(/ /g, '-').replace(/[^a-z0-9-]/g, '');
}

async function addManyGames() {
    // Load JSON array from 'gamedata.json'
    const data = await fs.readFile('./gamedata.json', 'utf8');
    const jsonArray = JSON.parse(data);

    // Add 'url' field to each game object
    jsonArray.forEach(game => {
        game.url = createUrlFromTitle(game.title);
    });

    // Connect to MongoDB
    const uri = 'mongodb+srv://eclipsesword777:HNcLrnsCMenbCxf6@cluster0.dvhrksp.mongodb.net/GameEcommerce?retryWrites=true&w=majority&appName=Cluster0';
    await mongoose.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true });

    try {
        // Insert the JSON objects into the Games model
        const result = await Games.insertMany(jsonArray);
        console.log('Data successfully added:', result);
    } catch (error) {
        console.error('Error adding data:', error);
    } finally {
        await mongoose.disconnect();
    }
}
addManyGames();
